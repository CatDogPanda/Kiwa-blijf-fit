function globalFunctions(){
	$( '.buttonRound' ).click(function( e ){
		e.preventDefault();
		$( this ).toggleClass('bordered');
	})
}



function pageButton( ell )
{
	$( '#'+ell+' #buttonOne').click( buttonClicked );
	$( '#'+ell+' #buttonTwo').click( buttonClicked );
	$( '#'+ell+' #buttonThree').click( buttonClicked );
	$( '#'+ell+' #buttonFour').click( buttonClicked );
	$( '#'+ell+' #buttonFive').click( buttonClicked );
	$( '#'+ell+' #buttonEx').click( buttonClicked );

	function buttonClicked( e ){
		e.preventDefault();
		gotoPage( 'next' );
	}

	
}


function pageInput( ell )
{
	$( '#'+ell+' #buttonSix').click( buttonClicked );
	$( '#'+ell+' #buttonSeven').click( buttonClicked );
	$( '#'+ell+' #buttonEight').click( buttonClicked );
	$( '#'+ell+' #buttonNine').click( buttonClicked );
	$( '#'+ell+' #buttonTen').click( buttonClicked );
	$( '#'+ell+' #buttonEleven').click( buttonClicked );
	$( '#'+ell+' #buttonTwelve').click( buttonClicked );
	$( '#'+ell+' #buttonThirtheen').click( buttonClicked );

	$( '#' + ell + ' #fysiek' ).click( buttonPressed );


	function buttonClicked( e ){
		e.preventDefault();
		gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
}

function pageInputTwo( ell )
{
	

	$( '#'+ell+' #buttonTwenty').click( buttonClicked );
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );

	function buttonClicked( e ){
		
			gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
}

function pageRadio( ell )
{
	

	$( '#'+ell+' #buttonTwentyt').click( buttonClicked );
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );

	function buttonClicked( e ){
		var value = $( 'input[type=radio]:checked' ).val();

	
			gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
}


function pagePhotoUpload( ell )
{
	

	
	$( '#'+ell+' #buttonTwentyo').click( buttonClicked );
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );

	function buttonClicked( e ){
		var value = $( 'input[type=radio]:checked' ).val();

	
			gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
}

function pageFinal( ell )
{
	

	$( '#'+ell+' #submit' ).click( buttonClicked );
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );

	function buttonClicked( e ){
		var value = $( 'input[type=radio]:checked' ).val();

	
			gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
}