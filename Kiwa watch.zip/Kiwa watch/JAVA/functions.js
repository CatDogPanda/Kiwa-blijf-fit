function globalFunctions(){
	$( '.buttonRound' ).click(function( e ){
		e.preventDefault();
		$( this ).toggleClass('bordered');
	})
}



function pageButton( ell )
{
	$( '#'+ell+' #buttonOne').click( buttonClicked );
	$( '#'+ell+' #buttonOne').click( buttonClicked );
	$( '#'+ell+' #buttonTwo').click( buttonClicked );
	$( '#'+ell+' #buttonThree').click( buttonClicked );
	$( '#'+ell+' #buttonFour').click( buttonClicked );
	$( '#'+ell+' #buttonFive').click( buttonClicked );
	$( '#'+ell+' #buttonSix').click( buttonClicked );
	$( '#'+ell+' #buttonSeven').click( buttonClicked );
	$( '#'+ell+' #buttonEight').click( buttonClicked );
	
	function buttonClicked( e ){
		e.preventDefault();
		gotoPage( 'next' );
	}


}


function pageInput( ell )
{
	
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );
	$( '#'+ell+' #buttonTen').click( buttonClicked );

	function buttonClicked( e ){
		e.preventDefault();
		gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
}

function pageInputTwo( ell )
{
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );
	$( '#'+ell+' #buttonTen').click( buttonClicked );

	function buttonClicked( e ){
		e.preventDefault();
		gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'pageButton' );
	}

	
}

function pageRadio( ell )
{
	$( '#'+ell+' #buttonEleven').click( buttonClicked );
	$( '#' + ell + ' #fysiek' ).click( buttonPressed );

	function buttonClicked( e ){
		e.preventDefault();
			gotoPage( 'next' );
		
	}

	function buttonPressed( e ){
		e.preventDefault();
		gotoPage( 'previous' );
	}
	

	


}

function pagePhotoUpload( ell )
{
	$( '#'+ell+' #buttonTwelve' ).click( buttonClicked );

	function buttonClicked( e ){
		e.preventDefault();	
		gotoPage( 'next' );
		
	}


}

function pageFinal( ell )
{
	

	$( '#'+ell+' #submit' ).click( buttonClicked );

	function buttonClicked( e ){
		e.preventDefault();
		gotoPage( 'next' );
		
	}
}

