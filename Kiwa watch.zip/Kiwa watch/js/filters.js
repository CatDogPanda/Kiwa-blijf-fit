$(document).ready( addFilters );

function addFilters()
{
	$( '.toggleSettings' ).click( toggleSettings );
}

function toggleSettings( e )
{
	$( '.settings' ).toggleClass( 'active' );
}